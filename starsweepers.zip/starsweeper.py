# 
import sqlite3
from Tkinter import *
import tkMessageBox
import random
import os
import time
import datetime


class Application(Frame):
    """ Star sweeper Game gui """
    def __init__(self, master):
        """ Initialize Frame. """
        Frame.__init__(self, master)
        self.colors = {0: "white", 1: "blue",2: "pink",3: "cyan", 4: "orange",5: "green",6: "yellow",7:"purple",8: "magenta"}
        self.difficulty = []
        self.difficulty.append({"difficulty": "Easy", "rows" : 8,  "columns": 8,  "bombs": 10})
        self.difficulty.append({"difficulty": "Medium","rows" : 16, "columns": 16, "bombs": 40})
        self.difficulty.append({"difficulty": "Hard","rows" : 20, "columns": 20, "bombs": 60})
        self.star = PhotoImage(file='images/star.png')
        self.smaller = PhotoImage(file='images/stars.png')
        self.logo = PhotoImage(file='images/rmcologo.png')
        self.a = []
        self.gameon = 1
        self.connec_db()
        self.diff  = self.difficulty[0]["difficulty"] 
        self.rows = self.difficulty[0]["rows"]
        self.columns  = self.difficulty[0]["columns"]
        self.bombs = self.difficulty[0]["bombs"]
        self.marks = self.bombs
        self.menu(master)
        self.reset()
        self.grid(sticky=N+S+E+W)


    def connec_db(self):
        try:
            self.conn = sqlite3.connect("starsweeperdb.db")
            self.cursor = self.conn.cursor()
        except ValueError, e:
            print(e)

    def menu(self, master):
        menu = Menu(master)
        master.config(menu=menu)

        subMenu = Menu(menu)
        menu.add_cascade(label="File", menu=subMenu)
        subMenu.add_command(label="New Game", command=lambda: self.new_game())
        subMenu.add_command(label="Highscore", command=lambda: self.view_highscore())
        subMenu.add_separator()
        subMenu.add_command(label="About", command=lambda: self.about())
        subMenu.add_command(label="Exit", command=root.quit)

    def about(self):
        self.abt = Toplevel(takefocus = True)
        self.abt.resizable(0,0)
        self.abt.grab_set()
        self.abt.title("About")
        self.abt.iconbitmap('@images/star.xbm')
        self.abt.lift(aboveThis=self)
        Label(self.abt, image=self.logo).pack()
        Label(self.abt, text="StarSweeper powered by Rinnas").pack()
        Button(self.abt, text="close", command=self.abt.destroy).pack()

    def view_highscore(self):
        self.high = Toplevel(takefocus = True)
        self.high.resizable(0,0)
        self.high.grab_set()
        self.high.title("Highscores")
        self.high.iconbitmap('@images/star.xbm')
        self.high.lift(aboveThis=self)
        Button(self.high, text="Clear", command=self.reset_highscore).pack(side=BOTTOM)
        Label(self.high, text="Highscores").pack()
        self.scores = Frame(self.high)
        self.get_highscore()
        self.scores.pack()

    def get_highscore(self, ):
        Label(self.scores, text="Name").grid(row=0, column=0)
        Label(self.scores, text="Difficulty").grid(row=0, column=1)
        Label(self.scores, text="Score").grid(row=0, column=2)
        Label(self.scores, text="Time").grid(row=0, column=3)
        try:
            sql = "SELECT * FROM highscore ORDER BY score DESC LIMIT 10"
            x = 1
            for row in self.cursor.execute(sql):
                Label(self.scores, text=row[0]).grid(row=x, column=0)
                Label(self.scores, text=row[1]).grid(row=x, column=1)
                Label(self.scores, text=row[2]).grid(row=x, column=2)
                Label(self.scores, text=row[3]).grid(row=x, column=3)
                x+=1
        except ValueError, e:
            pass

    def add_highscore(self):
        self.add_high = Toplevel(takefocus = True)
        self.add_high.resizable(0,0)
        self.add_high.grab_set()
        self.add_high.iconbitmap('@images/star.xbm')
        self.title("Add highscore")
        self.add_high.lift(aboveThis=self)
        Label(self.add_high, text="Add highscore").pack()
        self.highscore_form = Frame(self.add_high)
        Label(self.highscore_form, text="Name").grid(row=0, column=0)
        self.highscore_name = StringVar()
        Entry(self.highscore_form, textvariable=self.highscore_name).grid(row=0, column=1, columnspan=2)
        Button(self.highscore_form, text="Submit Score", command=self.add_highscore_db).grid(row=1, column=0, columnspan=3)
        self.highscore_form.pack()


    def add_highscore_form(self):
        self.highscore_form = Frame(self.add_high).pack()
        Label(self.highscore_form, text="Name").grid(row=0, column=0)
        self.highscore_name = StringVar()
        Entry(self.highscore_form, textvariable=self.highscore_name).grid(row=0, column=1, columnspan=2)
        Button(self.highscore_form, text="Submit Score", command=self.add_highscore_db).grid(row=1, column=0, columnspan=3)

    def add_highscore_db(self):
        self.add_high.destroy()
        date = str(datetime.datetime.fromtimestamp(int(time.time())).strftime('%Y-%m-%d %H:%M:%S'))
        name = self.highscore_name.get()
        score = self.gen_scores()
        self.cursor.execute("INSERT INTO highscore (name, difficulty, score, time) VALUES (?,?,?,?)",
                (self.highscore_name.get(), self.diff, score, date))
        self.conn.commit()
        self.view_highscore()

    def reset_highscore(self):
        self.high.destroy()
        self.cursor.execute("DELETE FROM highscore")
        self.conn.commit()
        self.cursor.execute("VACUUM")
        self.conn.commit()
        self.view_highscore()        

    def new_game(self):
        self.new = Toplevel(takefocus = True)
        self.new.lift(aboveThis=self)
        self.new.grab_set()
        self.new.resizable(0,0)
        self.new.title("New Game")
        self.new.iconbitmap('@images/star.xbm')
        Label(self.new, text="New Game").pack()
        for x in self.difficulty:
            Button(self.new, text=x["difficulty"], command=lambda x=x: self.start_game(x)).pack(side=LEFT)

        Button(self.new, text="Custom", command=self.custom_game).pack(side=LEFT)


    def custom_game(self):
        self.new.destroy()
        self.custom = Toplevel(takefocus = True)
        self.custom.lift()
        self.custom.title("Custom Game")
        self.custom.grab_set()
        self.custom.iconbitmap('@images/star.xbm')
        Label(self.custom, text="Create Custom Game").grid(row=0,column=0, columnspan=3)
        Label(self.custom, text="Rows").grid(row=1, column=0)
        self.custom_rows=IntVar()
        Entry(self.custom, textvariable=self.custom_rows).grid(row=1, column=1, columnspan=2)
        
        Label(self.custom, text="Columns").grid(row=2, column=0)
        self.custom_columns=IntVar()
        Entry(self.custom, textvariable=self.custom_columns).grid(row=2, column=1, columnspan=2)
        
        Label(self.custom, text="Bombs").grid(row=3, column=0)
        self.custom_bombs=IntVar()
        Entry(self.custom, textvariable=self.custom_bombs).grid(row=3, column=1, columnspan=2)
        
        button = Button(self.custom, text="Start Custom Game", 
            command=lambda :self.start_custom_game(self.custom_rows, self.custom_columns ,self.custom_bombs))
        button.grid(row=4 , column=1, columnspan=3)

    def start_custom_game(self, rows, columns, bombs):
        self.custom.destroy()
        self.gameon = 1
        if self.custom_rows.get() < 1 or self.custom_bombs.get() < 1 or self.custom_columns.get() < 1:
            tkMessageBox.showwarning("No zeroes", "rows/columns/bombs must not be zero")
            self.custom_game()
        elif self.custom_rows.get() * self.custom_columns.get() <  self.custom_bombs.get():
            tkMessageBox.showwarning("Too many bombs", "total bombs must be less than the product of rows and columns")
            self.custom_game()
        else:
            self.diff  = "Custom"
            self.rows = self.custom_rows.get()
            self.columns  = self.custom_columns.get()
            self.bombs = self.custom_bombs.get()
            self.marklabel["text"] = self.bombs
            self.bomblabel["text"] = self.bombs
            self.reset()        



    def start_game(self, level):
        self.new.destroy()
        self.gameon = 1
        self.diff  = level["difficulty"] 
        self.rows = level['rows']
        self.columns  = level['columns']
        self.bombs = level['bombs']
        self.marklabel["text"] = self.bombs
        self.bomblabel["text"] = self.bombs
        self.reset()


    def create_scoreboard(self):
        self.scoreboard = Frame(self, relief=GROOVE, bg="black", borderwidth=0)
        self.scoreboard.grid(row=0, column=0, columnspan=self.columns)
        self.marklabel = Label(self.scoreboard, text=self.marks, anchor=W, font="DS-Digital 20",bg="black", fg="white", padx=20)
        self.marklabel.pack(side=LEFT)
        Button(self.scoreboard, text="NEW GAME", command=self.reset, image=self.star).pack(side=LEFT)
        self.bomblabel = Label(self.scoreboard, text=self.bombs, anchor=E, font="DS-Digital 20",bg="black", fg="white", padx=20)
        self.bomblabel.pack(side=RIGHT)

    def create_widgets(self):
        """ Create widgets to get story information and to display story. """
        self.b = []
        for x in range(self.rows):
            self.c = []
            for y in range(self.columns):
                button = Button(self, width=1, height=1, text = "  ", background="black", font="DS-Digital", relief=FLAT, borderwidth=0)
                self.c.append(button)
                button.grid(row = x+1, column = y, sticky=N+S+E+W)
                data = {"x": x, "y": y}
                button.bind("<Button-1>", lambda x=x, y=y,arg=data: self.check(self, arg))
                button.bind("<Button-3>", lambda x=x, y=y,arg=data: self.mark(self, arg))
            self.b.append(self.c)

    def gen_scores(self):
        myscore = (self.rows * self.columns) * self.bombs 
        timer = int(time.time()) - self.time
        if timer < 200:
            final = myscore + (myscore/timer)
        else:
            final = myscore - (myscore/timer)
        return final


    def bomb(self, event, data):
        tkMessageBox.showinfo("BOMB","BOOOOOOOM")

    def mark(self, event, data):
        x = data["x"]
        y = data["y"]
        if self.gameon == 1:
            if self.b[x][y]["state"] != "disabled":
                if self.b[x][y]["text"] != "?":
                    self.b[x][y].configure(text = "?", fg="white")
                    self.marks-=1
                else :
                    self.b[x][y].configure(text = "  ")
                    self.marks+=1
                self.marklabel["text"] = self.marks
            if self.marks == 0:
                self.complete()

    def complete(self):
        correct = 0
        for d in self.a:
            v =d.split(",")
            x = int(v[0])
            y = int(v[1])
            if self.b[x][y]["text"] == "?":
                correct+= 1
        if correct != self.bombs:
            self.gameover()
        else:
            tkMessageBox.showinfo("Victory", "You win!!!!!");
            self.add_highscore()


    def check(self,event, data):
        x = data["x"]
        y = data["y"]
        msg = " "
        m2 = ""
        if self.gameon == 1:
            if self.b[x][y]["text"] != "?":
                if str(x)+","+str(y) in self.a:
                    self.gameover(x,y)
                else:
                    count = self.checksurround2(x,y)
                    if(count == 0):
                        self.checksurround(x,y)
                        self.b[x][y].configure(bg=self.colors[count], state="disabled")
                    else:
                        m2 = str(count)
                        self.b[x][y].configure(text = m2, disabledforeground=self.colors[count], state="disabled")

    def gameover(self,dx=None,dy=None):
        for x in range(self.rows):
            self.c = []
            for y in range(self.columns):
                d = str(x)+","+str(y)
                if d in self.a:
                    if d == str(dx)+","+str(dy):
                        self.b[x][y].configure(image=self.smaller, width=30, height=25,bg="white", state= "normal", anchor=CENTER)
                    else:
                        self.b[x][y].configure(image=self.smaller, width=30, height=25,bg="red", state= "normal", anchor=CENTER)
                else:
                    count = self.checksurround2(x,y)
                    m2 = str(count)
                    if count == 0:
                        self.b[x][y].configure(text=" ", state= "disabled", bg=self.colors[count])
                    else:
                        self.b[x][y].configure(text = m2, state= "disabled", disabledforeground=self.colors[count])
        tkMessageBox.showwarning("Game Over", "You lose try again")
        self.gameon = 0  
    def checksurround(self, x, y):
        count = 0
        surround = (-1,0,1)
        for x1 in surround:
            for y1 in surround:
                if str(x+x1)+","+str(y+y1) in self.a:        
                    count = count + 1
                else:
                    if x+x1 < self.rows and y+y1 < self.columns and x+x1 >= 0 and y+y1 >= 0:
                        m2 = self.checksurround2(x+x1, y+y1)
                        if self.b[x+x1][y+y1]["text"] != "?":
                            if m2 == 0:
                                self.b[x+x1][y+y1].configure(state= "disabled", bg=self.colors[int(m2)])
                            else:
                                self.b[x+x1][y+y1].configure(text = m2, state= "disabled", disabledforeground=self.colors[int(m2)])    
        return count

    def checksurround2(self, x, y):
        count = 0
        surround = (-1,0,1)
        for x1 in surround:
            for y1 in surround:
                if str(x+x1)+","+str(y+y1) in self.a:
                    count = count + 1
        return count    

    def reset(self):
        self.a = []
        self.gameon = 1
        self.set_bombs()
        self.time = int(time.time())
        for widget in self.winfo_children():
            widget.destroy()
        self.marks = self.bombs
        self.create_scoreboard()
        self.create_widgets()


    def set_bombs(self):
        bombs = str(random.randint(0,self.rows-1))+","+str(random.randint(0,self.columns-1))
        x = 0
        for i in self.a:
            x+=1
        if x < self.bombs:
            if bombs in self.a:
                self.set_bombs()
            else:
                self.a.append(bombs)
                self.set_bombs()

# main
root = Tk()
root.title("Star Sweeper")
root.resizable(0,0)
app = Application(root)
root.iconbitmap('@images/star.xbm')
root.mainloop()